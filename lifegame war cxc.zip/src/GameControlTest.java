import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GameControlTest {
    GameControl gameControl;
    @BeforeEach
    void setUp() {
        gameControl=new GameControl(10,10);
    }
    
    @Test
    void deleteMap() {
        gameControl.deleteMap();
    }
    
    @Test
    void reinitMap() {
        gameControl.reinitMap();
    }
}